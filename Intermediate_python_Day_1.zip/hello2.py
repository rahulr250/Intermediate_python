def say_hello(name):
    print(f'Hello-2 {name}')