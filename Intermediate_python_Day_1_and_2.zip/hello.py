def say_hello(name:str):
    print(f'Hello {name}')