import os
import time
import threading
print('Process Begin')
print(f'Process id: {os.getpid()}')
print(f'Current Thread name: {threading.current_thread().name}')
print('Sleeping')
time.sleep(5)
threading.current_thread().name = 'MyThread'
print(f'Current Thread name: {threading.current_thread().name}')
print('Process Exit')
